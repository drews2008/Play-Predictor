import React from "react";
import { OffensivePlayLogEntry } from "../../types/OffensivePlayLogEntry";

interface Props {
  playLog: OffensivePlayLogEntry[];
}

const getDownDistance = (down?: number, distance?: number) => {
  const d = Number(distance);
  const dn = Number(down);
  switch (dn) {
    case 1:
      return "1st & 10";
    case 2:
      if (d <= 3) return "2nd & 1–3";
      if (d <= 7) return "2nd & 4–7";
      return "2nd & 8+";
    case 3:
      if (d <= 3) return "3rd & 1–3";
      if (d <= 7) return "3rd & 4–7";
      return "3rd & 8+";
    case 4:
      return "4th Down";
    default:
      return "Other";
  }
};

const SituationalTendencies: React.FC<Props> = ({ playLog }) => {
  const grouped: Record<string, { run: number; pass: number; total: number }> = {};

  playLog.forEach((p) => {
    const key = getDownDistance(p.down, p.distance);
    if (!grouped[key]) grouped[key] = { run: 0, pass: 0, total: 0 };
    grouped[key].total++;
    if ((p.playType ?? "").toLowerCase().includes("run")) grouped[key].run++;
    else grouped[key].pass++;
  });

  const order = [
    "1st & 10",
    "2nd & 1–3",
    "2nd & 4–7",
    "2nd & 8+",
    "3rd & 1–3",
    "3rd & 4–7",
    "3rd & 8+",
    "4th Down",
    "Other",
  ];

  return (
    <div>
      <h3 className="text-lg font-semibold mb-2 text-blue-700">Situational Tendencies</h3>
      <table className="min-w-full border text-sm">
        <thead className="bg-blue-600 text-white">
          <tr>
            <th className="border px-2 py-1 text-left">Situation</th>
            <th className="border px-2 py-1 text-left">Run %</th>
            <th className="border px-2 py-1 text-left">Pass %</th>
          </tr>
        </thead>
        <tbody>
          {order
            .filter((s) => grouped[s])
            .map((s, i) => {
              const g = grouped[s];
              const runPct = ((g.run / g.total) * 100).toFixed(0);
              const passPct = ((g.pass / g.total) * 100).toFixed(0);
              return (
                <tr key={i} className="even:bg-blue-50">
                  <td className="border px-2 py-1">{s}</td>
                  <td className="border px-2 py-1">{runPct}%</td>
                  <td className="border px-2 py-1">{passPct}%</td>
                </tr>
              );
            })}
        </tbody>
      </table>
    </div>
  );
};

export default SituationalTendencies;
