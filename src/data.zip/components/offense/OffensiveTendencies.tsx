import React from "react";
import { OffensivePlayLogEntry } from "../../types/OffensivePlayLogEntry";

interface Props {
  playLog: OffensivePlayLogEntry[];
}

const OffensiveTendencies: React.FC<Props> = ({ playLog }) => {
  const runPlays = playLog.filter(p => p.playType === "Run");
  const passPlays = playLog.filter(p => p.playType === "Pass");

  const runPct = ((runPlays.length / playLog.length) * 100).toFixed(1);
  const passPct = ((passPlays.length / playLog.length) * 100).toFixed(1);

  return (
    <div>
      <h3 className="text-xl font-semibold mb-2">Overall Play Type Tendencies</h3>
      <p>Run: {runPct}% ({runPlays.length})</p>
      <p>Pass: {passPct}% ({passPlays.length})</p>

      <h3 className="text-xl font-semibold mt-4 mb-2">Plays by Formation</h3>
      <table className="border-collapse border border-gray-300 w-full">
        <thead>
          <tr>
            <th className="border p-2">Formation</th>
            <th className="border p-2">Run</th>
            <th className="border p-2">Pass</th>
          </tr>
        </thead>
        <tbody>
          {Array.from(new Set(playLog.map(p => p.formation))).map(formation => {
            const runs = playLog.filter(p => p.formation === formation && p.playType === "Run").length;
            const passes = playLog.filter(p => p.formation === formation && p.playType === "Pass").length;
            return (
              <tr key={formation}>
                <td className="border p-2">{formation}</td>
                <td className="border p-2">{runs}</td>
                <td className="border p-2">{passes}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  );
};

export default OffensiveTendencies;
