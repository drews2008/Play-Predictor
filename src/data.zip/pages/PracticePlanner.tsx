export default function PracticePlanner() {
  return (
    <div>
      <h1>Practice Planner</h1>
      <p>Welcome to the practice planner!</p>
    </div>
  );
}
