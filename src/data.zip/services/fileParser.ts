import Papa from "papaparse";
import { OffensivePlayLogEntry } from "../types/OffensivePlayLogEntry";

/** Normalize a CSV key so matching is case-insensitive and spacing-agnostic */
function normalizeKey(key: string): string {
  return key.trim().toLowerCase().replace(/\s+/g, "");
}

/** Flexible getter that can check multiple possible header names */
function getValue(row: Record<string, any>, ...possibleKeys: string[]): any {
  for (const key of possibleKeys) {
    const normalized = normalizeKey(key);
    for (const rowKey in row) {
      if (normalizeKey(rowKey) === normalized) {
        const value = row[rowKey];
        if (value !== undefined && value !== null && value !== "") return value;
      }
    }
  }
  return undefined;
}


/** Normalize any CSV row into a clean OffensivePlayLogEntry */
function normalizeOffensiveCSVrow(row: Record<string, any>): OffensivePlayLogEntry {
  const down = Number(getValue(row, "Down")) as OffensivePlayLogEntry["down"];
  const distance = Number(getValue(row, "Distance"));
  
  const valPlay = String(getValue(row, "Play", "Play Type", "Call") || "").toLowerCase();
  const playType: OffensivePlayLogEntry["playType"] = valPlay
    ? valPlay.includes("pass")
      ? "Pass"
      : "Run"
    : undefined;

  const ballVal = String(getValue(row, "Ball Placement", "Hash", "Ball Spot") || "").toLowerCase();
  const ballPlacement: OffensivePlayLogEntry["ballPlacement"] =
    ballVal.includes("left") ? "Left" : ballVal.includes("right") ? "Right" : "Middle";

  return {
    down: down >= 1 && down <= 4 ? down : undefined as any,
    distance: !isNaN(distance) ? distance : undefined as any,
    tapeCue: String(getValue(row, "Tape Cue", "Cue", "Tag") || undefined),
    fieldPosition: parseInt(String(getValue(row, "Field Position", "Yard Line") || "")) || undefined,
    ballPlacement,
    driveStarter: String(getValue(row, "Drive Starter", "Drive Start"))?.toLowerCase() === "yes",
    driveNumber: Number(getValue(row, "Drive Number", "Drive No", "Drive #")) || undefined,
    playType,
    formation: String(getValue(row, "Formation", "Form") || ""),
    playName: String(getValue(row, "Play Name", "Name", "Call", "PlayName") || ""),
    result: String(getValue(row, "Result of Play", "Result", "Outcome") || undefined),
    yardageGained: Number(getValue(row, "Yardage Gained", "Yards", "Gain", "Yardage gained", "Yds")) || undefined,
    notes: String(getValue(row, "Notes", "Comments", "Remarks") || undefined),
  };
}
/** Parse CSV string content into normalized offensive play log entries */
export function parseOffensiveCSV(fileContent: string): OffensivePlayLogEntry[] {
  const parsed = Papa.parse(fileContent, { header: true });
  return (parsed.data as Record<string, any>[])
    .filter((row) => Object.keys(row).length > 0)
    .map(normalizeOffensiveCSVrow);
}
