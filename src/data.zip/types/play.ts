export interface Play {
  Down: string;
  Distance: string;
  Formation: string;
  Play: string;
  'Ball placement': string;
  'Drive starter': string;
}
